
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <h3 class="text-center">
            Manajemen Produk
        </h3>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <table class="table">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Deskripsi</th>
                    <th scope="col">Harga</th>
                    <th scope="col">Jumlah</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php ($count = 1); ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <th scope="row"><?php echo e($count); ?></th>
                    <td><?php echo e($post->nama); ?></td>
                    <td><?php echo e($post->deskripsi); ?></td>
                    <td><?php echo e($post->harga); ?></td>
                    <td><?php echo e($post->jumlah); ?></td>
                    <td>
                        <a href="<?php echo e(url('edit',$post->id)); ?>">
                            <button type="button" class="btn btn-danger ">Update</button>
                        </a>
                        <a href="<?php echo e(url('delete',$post->id)); ?>">
                            <button type="button" class="btn btn-danger ">Delete</button>
                        </a>
                    </td>
                </tr>
                <?php ($count++); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>



<?php echo $posts->links(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\File\kasir\resources\views/posts/manajemen.blade.php ENDPATH**/ ?>