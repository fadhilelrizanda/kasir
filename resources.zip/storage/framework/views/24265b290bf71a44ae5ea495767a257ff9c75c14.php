

<?php $__env->startSection('content'); ?>

<div class="row spacer">
    <div class="col-md-12">
        <h1 class="text-center">List Produk</h1>

    </div>
</div>

<?php $__currentLoopData = $posts->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row spacer">
    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-6 mb-4">
        <div class="card listProduct">
            <img class="card-img-top pasfoto" src="<?php echo e(asset('images/' . $post->path_img)); ?>" alt="Card image cap">
            <div class="card-body">
                <p class="card-text"><?php echo e($post->nama); ?></p>
                <p class="card-text"><?php echo e($post->deskripsi); ?></p>
                <p class="card-text"><?php echo e($post->harga); ?></p>
                <p class="card-text"><?php echo e($post->jumlah); ?></p>

            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $posts->links(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\File\kasir\resources\views/posts/index.blade.php ENDPATH**/ ?>