<!DOCTYPE html>
<html>

<head>
    <title>Produk Kasir Online </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>

<body>
    <div class="row">
        <div class="col-md-4">
            <div class="card text-white bg-primary mb-3">
                <div class="card-header text-center">Produk Kasir Online Kita</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <img src="https://getbootstrap.com/docs/4.0/assets/brand/bootstrap-social-logo.png" class="img-fluid" alt="Responsive image">
                        </div>
                    </div>
                    <button type="button" class="btn btn-block btn-primary">Home</button>
                    <button type="button" class="btn btn-block btn-secondary">Stok Barang</button>
                    <button type="button" class="btn btn-block btn-success">Login</button>

                </div>

            </div>

        </div>
        <div class="col-md-8">
            <div class="container card bg-light">
                <?php echo $__env->yieldContent('content'); ?>

            </div>
        </div>




    </div>

</body>

</html><?php /**PATH C:\xampp\htdocs\Laravel\File\contoh_kasir\resources\views/template.blade.php ENDPATH**/ ?>